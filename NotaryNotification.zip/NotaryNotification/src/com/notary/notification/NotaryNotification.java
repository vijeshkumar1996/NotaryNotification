/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.notary.notification;


import com.ibm.json.java.JSON;
import com.ibm.json.java.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import com.notary.config.NotaryConfig;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Chandan
 */
public class NotaryNotification {

    public static final Logger LOGGER = Logger.getLogger(NotaryNotification.class.getName());
    /**
     *
     * @return
     */
    public String getUserToken() {
        LOGGER.log(Level.INFO, "<====getUserToken() ====>");
        HttpURLConnection connection = null;
        JSONObject json = null;
        String token = null;
        try {
              String uriString=NotaryConfig.getProp("Authentication_URL");
        String userName=NotaryConfig.getProp("Authentication_userName");
        String password=NotaryConfig.getProp("Authentication_password");
         LOGGER.log(Level.INFO, "username: {0}   -->URL: {1}", new Object[]{userName, uriString});
//            String uriString = "http://172.16.1.159:8090/api/v1/client/authenticate";
            URL url = new URL(uriString);
            connection = (HttpURLConnection) url.openConnection();
             LOGGER.log(Level.INFO, "<====Connection() ====>{0}", connection);
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("Accept", "*/*");
            connection.setRequestProperty("Accept-Encoding", "gzip, deflate, br");
            connection.setRequestProperty("Connection", "keep-alive");
            connection.setDoOutput(true);
//            String userName = "hossam";
//            String password = "q9nDp35JHTsObsC75l6wNXK8lLh4p31Oy38xI/5KOLr7mnSpaX1/7gk3N+y1kwOGYvy7FrS2x8RBQ1UyNEIQvTrqBtbsL8PHbEklYdExzi7XhFrI1DLp1myfcR4OCOQG19ITmO14ycXf+yq0xKwz31CRHwjF3GKr1Y4ZaklPOcg=";
            String jsonInputString = "{\n"
                    + "    \"userCredential\": {\n"
                    + "        \"userName\": \"" + userName + "\",\n"
                    + "        \"password\": \"" + password + "\"\n"
                    + "    }\n"
                    + "}";
             LOGGER.log(Level.INFO, "<====jsonInputString() ====>{0}", jsonInputString);
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonInputString.getBytes("utf-8");
                 LOGGER.log(Level.INFO, "<====Input====>{0}", input);
                os.write(input, 0, input.length);
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "Error:  {0}", e.getMessage());
                e.printStackTrace();
            }
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(connection.getInputStream(), "utf-8"))) {
                 LOGGER.log(Level.INFO, "<====BufferedReader() ====>{0}", br);  
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
                 LOGGER.log(Level.INFO, "<====Response() ====>{0}", response);  
                json = new JSONObject();
                json = (JSONObject) JSON.parse(response.toString());
                token = json.get("accessToken").toString();
             LOGGER.log(Level.INFO, "<====token() ====>{0}", token);   
            }
        } catch (MalformedURLException e1) {
            LOGGER.log(Level.SEVERE, "MalformedURLException:  {0}", e1.getMessage());
            e1.printStackTrace();
        } catch (ProtocolException e) {
            LOGGER.log(Level.SEVERE, "ProtocolException:  {0}", e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "IOException:  {0}", e.getMessage());
            e.printStackTrace();
        } catch (NullPointerException e) {
            LOGGER.log(Level.SEVERE, "{0}NullPointerException:  ", e.getMessage());
            System.out.println("EXCEPTION OCCURED------------------->");
            e.printStackTrace();
        } catch(Exception ee){
            LOGGER.log(Level.SEVERE, "Exception:  {0}", ee.getMessage());
            System.out.println("EXCEPTION OCCURED------------------->");
            ee.printStackTrace();
        }
        finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        return token;
    }

    public void sendNotification(String serviceUrl, int requestId, int notificationId) {
        LOGGER.log(Level.INFO, "<====sendNotification() ====>");
        HttpURLConnection connection = null;
        String token = null;
        try {
            String uriString = serviceUrl + requestId + "/notificationtype/" + notificationId;
            token = getUserToken();
            LOGGER.log(Level.INFO, "<====sendNotification.got token() ====>{0}", token);
            LOGGER.log(Level.INFO, "<====sendNotification.URI String() ====>{0}", uriString);
            URL url = new URL(uriString);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("Accept", "*/*");
            connection.setRequestProperty("Accept-Encoding", "gzip, deflate, br");
            connection.setRequestProperty("Connection", "keep-alive");
            connection.setRequestProperty("Authorization", "Bearer " + token);
            connection.setDoOutput(true);
            LOGGER.log(Level.INFO, "<====sendNotification.Connection() ====>{0}", connection);
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(connection.getInputStream(), "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
                LOGGER.log(Level.INFO, "<====sendNotification.response() ====>{0}", response);
                System.out.println("response--" + response.toString());
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "<====sendNotification.Exception() ====>{0}", e.getMessage());
            e.printStackTrace();
            System.out.println("Exception Occured while sending notification---" + e.getLocalizedMessage());
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        NotaryNotification nt = new NotaryNotification();
//        nt.getUserToken();
        String authenticationURL=NotaryConfig.getProp("Authentication_URL");
        String authenticationUserName=NotaryConfig.getProp("Authentication_userName");
        String authenticationPassword=NotaryConfig.getProp("Authentication_password");
        String notificationURL=NotaryConfig.getProp("notificationAPI_URL");
        System.out.println("authenticationUserName:: "+authenticationUserName);
        System.out.println("authenticationPassword:: "+authenticationPassword);
        System.out.println("Authentication url:: "+authenticationURL);
        System.out.println("notificationURL url:: "+notificationURL);
        
        nt.sendNotification(notificationURL, 76, 1);
//        nt.getUserToken();
    }

}
