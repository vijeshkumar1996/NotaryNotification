package com.notary.configpropertymanager;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import java.util.logging.Logger;

public class ConfigPropertyManager {

    public static Properties props = null;

    //start logger
    public static final Logger LOGGER = Logger.getLogger(ConfigPropertyManager.class.getName());

//    static {
//        try {
//
//            if (ConfigPropertyManager.getProp("logOutput").equals("file") || ConfigPropertyManager.getProp("logOutput").equals("both")) //LOGGER.addHandler(com.batelco.Logger.ConfigLogger.fileHandler);
//            {
//                if (ConfigPropertyManager.getProp("logOutput").equals("console") || ConfigPropertyManager.getProp("logOutput").equals("both")) {
//                    LOGGER.addHandler(com.sohar.Logger.ConfigLogger.consoleHandler);
//                }
//            }
//
//        } catch (Exception exception) {
//            System.out.println("Error in " + ConfigPropertyManager.class.getName() + " while loading logger " + exception);
//        }
//    }

    //end logger
    public static void loadProps() throws IOException {
        if (props == null) {
            props = new Properties();
            //LOGGER.info("Loading /com/ecm/resources/Config.properties");
            InputStream inputstream = ConfigPropertyManager.class.getResourceAsStream("/com/notary/config/Config.properties");
            props.load(inputstream);
        }
    }

    public static String getProp(String key) {
        try {
            if (props == null) {
                loadProps();
            }
        } catch (Exception e) {

            //LOGGER.log(Level.SEVERE, "Exception at loadProps of ConfigPropertyManager " + e);
            return null;
        }
        return props.getProperty(key);
    }
}
