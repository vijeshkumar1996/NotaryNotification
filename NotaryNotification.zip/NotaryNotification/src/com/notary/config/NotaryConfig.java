/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.notary.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 *
 * @author Subhash.G
 */
public class NotaryConfig {
    
      public static Properties props = null;
      public static void loadProps() throws IOException {
        if (props == null) {
            props = new Properties();
            InputStream inputstream = NotaryConfig.class.getResourceAsStream("/com/notary/config/Config.properties");
            props.load(inputstream);
        }
    }
      
      public static String getProp(String key) {
        try {
            if (props == null) {
                loadProps();
            }
        } catch (Exception e) {
            return null;
        }
        return props.getProperty(key);
    }
}
