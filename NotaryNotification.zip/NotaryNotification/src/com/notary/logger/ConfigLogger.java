package com.notary.logger;


import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import com.notary.configpropertymanager.ConfigPropertyManager;



public class ConfigLogger {

	public static final LogManager logManager = LogManager.getLogManager();
	public static final Logger LOGGER = Logger.getLogger(ConfigLogger.class.getName());
	public static Handler consoleHandler = null;
	public static Handler fileHandler  = null;
	
	static{
		System.out.println("Loading ConfigLogger");
		try {
			InputStream is = ConfigLogger.class.getResourceAsStream("/com/notary/config/ConfigLogger.properties");
			logManager.readConfiguration(is);
			consoleHandler = new ConsoleHandler();			
			//fileHandler  = new FileHandler(ConfigPropertyManager.getProp("logFileNameLocation"));
			Date curDate = new Date();			
			SimpleDateFormat format = new SimpleDateFormat("yyyyMMMdd_kka");
			String DateToStr = format.format(curDate);			
			//fileHandler = new FileHandler(ConfigPropertyManager.getProp("logFileNameLocation")+"/"+DateToStr+"_log.%u.%g.txt",1024 * 1024, 10, true);
			fileHandler = new FileHandler(ConfigPropertyManager.getProp("logFileNameLocation")+"/"+DateToStr+"_log.%u.%g.txt",20000000, 200);
			if(ConfigPropertyManager.getProp("logOutput").equals("file") || ConfigPropertyManager.getProp("logOutput").equals("both")) 
			LOGGER.addHandler(fileHandler);
			if(ConfigPropertyManager.getProp("logOutput").equals("console") || ConfigPropertyManager.getProp("logOutput").equals("both")) 
				LOGGER.addHandler(consoleHandler);
				
			
		} catch (IOException exception) {
			LOGGER.log(Level.SEVERE, "Error in loading configuration",exception);
		}
	}
	public static void main(String[] args) {
		System.out.println("Logger initiating");
		
	}
}
